Variance Shadow Maps FX Composer Files:

These FX Composer files implement the bare minimum of Variance Shadow Maps, just to give the idea. To really get the advantages, one should use mipmapping/anisotropic filtering and potentially a pre-processing blur step. See the paper "Variance Shadow Maps" for more details.

William Donnelly, Andrew Lauritzen